function accept() {
    alert("Gracias, te esperamos")
}

function reject() {
    alert("Una pena, ojala hubieses podido")
}